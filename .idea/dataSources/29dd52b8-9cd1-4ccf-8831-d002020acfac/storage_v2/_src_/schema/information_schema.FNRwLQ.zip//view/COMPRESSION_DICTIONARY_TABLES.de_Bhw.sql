create view COMPRESSION_DICTIONARY_TABLES as
select `sch`.`name`  AS `TABLE_SCHEMA`,
       `tbl`.`name`  AS `TABLE_NAME`,
       `col`.`name`  AS `COLUMN_NAME`,
       `dict`.`name` AS `DICT_NAME`
from ((((`mysql`.`compression_dictionary_cols` `cdc` join `mysql`.`tables` `tbl`
         on ((`cdc`.`table_id` = `tbl`.`id`))) join `mysql`.`columns` `col`
        on (((`col`.`table_id` = `cdc`.`table_id`) and (`col`.`id` = `cdc`.`column_id`)))) join `mysql`.`schemata` `sch`
       on ((`tbl`.`schema_id` = `sch`.`id`))) join `mysql`.`compression_dictionary` `dict`
      on ((`dict`.`id` = `cdc`.`dict_id`)));

