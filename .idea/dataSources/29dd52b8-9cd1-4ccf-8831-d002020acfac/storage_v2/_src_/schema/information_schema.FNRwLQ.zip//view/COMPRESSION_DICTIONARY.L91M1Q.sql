create view COMPRESSION_DICTIONARY as
select `dict`.`version` AS `DICT_VERSION`, `dict`.`name` AS `DICT_NAME`, `dict`.`data` AS `DICT_DATA`
from `mysql`.`compression_dictionary` `dict`;

